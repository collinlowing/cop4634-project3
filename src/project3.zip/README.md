Author: Collin Lowing

I could not get the threads to initialize on line 682 and line 687 with the code that was given to me.

besides this problem, all functionality should be implemented.

I did not get any help from Charles Travis. This is a reoccurring issue. He usually tries to help with little actual contributes on the core coding aspects of the project but assist plenty fine with the reports. However, this time I got little to no communication from him and worked on this project alone.